import * as universal from "../../../../src/routes/[id]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/[id]/+page.svelte";
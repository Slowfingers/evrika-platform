import * as universal from "../../../../src/routes/admin/[id]/edit/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/admin/[id]/edit/+page.svelte";